/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'lt', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Patariamas pavadinimas',
	cssClassInputLabel: 'Stilių klasės',
	edit: 'Redaguoti Div',
	inlineStyleInputLabel: 'Vidiniai stiliai',
	langDirLTRLabel: 'Iš kairės į dešinę (LTR)',
	langDirLabel: 'Kalbos nurodymai',
	langDirRTLLabel: 'Iš dešinės į kairę (RTL)',
	languageCodeInputLabel: ' Kalbos kodas',
	remove: 'Pašalinti Div',
	styleSelectLabel: 'Stilius',
	title: 'Sukurti Div elementą',
	toolbar: 'Sukurti Div elementą'
} );
