/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'lv', {
	IdInputLabel: 'Id',
	advisoryTitleInputLabel: 'Konsultatīvs virsraksts',
	cssClassInputLabel: 'Stilu klases',
	edit: 'Labot Div',
	inlineStyleInputLabel: 'Iekļautais stils',
	langDirLTRLabel: 'Kreisais uz Labo (LTR)',
	langDirLabel: 'Valodas virziens',
	langDirRTLLabel: 'Labais uz kreiso (RTL)',
	languageCodeInputLabel: 'Valodas kods',
	remove: 'Noņemt Div',
	styleSelectLabel: 'Stils',
	title: 'Izveidot div konteineri',
	toolbar: 'Izveidot div konteineri'
} );
