/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'pt', {
	IdInputLabel: 'ID',
	advisoryTitleInputLabel: 'Título',
	cssClassInputLabel: 'Classes de folhas de estilo',
	edit: 'Editar Div',
	inlineStyleInputLabel: 'Estilho em Linha',
	langDirLTRLabel: 'Esquerda para a direita (EPD)',
	langDirLabel: 'Orientação de idioma',
	langDirRTLLabel: 'Direita para a Esquerda (DPE)',
	languageCodeInputLabel: 'Codigo do Idioma',
	remove: 'Remover Div',
	styleSelectLabel: 'Estilo',
	title: 'Criar Div',
	toolbar: 'Criar Div'
} );
