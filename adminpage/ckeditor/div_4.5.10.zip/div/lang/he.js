/*
Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'div', 'he', {
	IdInputLabel: 'מזהה (ID)',
	advisoryTitleInputLabel: 'כותרת מוצעת',
	cssClassInputLabel: 'מחלקת עיצוב',
	edit: 'עריכת מיכל (Div)',
	inlineStyleInputLabel: 'סגנון פנימי',
	langDirLTRLabel: 'שמאל לימין (LTR)',
	langDirLabel: 'כיוון שפה',
	langDirRTLLabel: 'ימין לשמאל (RTL)',
	languageCodeInputLabel: 'קוד שפה',
	remove: 'הסרת מיכל (Div)',
	styleSelectLabel: 'סגנון',
	title: 'יצירת מיכל (Div)',
	toolbar: 'יצירת מיכל (Div)'
} );
